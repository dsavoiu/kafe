#!/bin/bash

# Uninstall script for kafe using pip

# Uninstall using pip
pip uninstall kafe
